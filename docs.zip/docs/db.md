# db.md — OrderItems Missing Columns Migration

## Tabel order_items

| Kolom | Tipe | Null | Default | FK | Komentar |
|-------|------|------|---------|-----|----------|
| id | bigIncrements | No | auto | — | Primery key |
| created_at | timestamp | No | current_timestamp | — | |
| updated_at | timestamp | No | current_timestamp | — | |
| deleted_at | timestamp | Yes | null | — | Soft delete |
| order_id | foreignId | Yes | null | FK → orders (restrict) | Relasi ke pesanan |
| variant_id | foreignId | Yes | null | FK → variants (restrict) | Relasi ke varian produk |
| product_id | foreignId | Yes | null | FK → products (set null) | Relasi ke produk |
| nama | string | Yes | null | — | Snapshot nama produk |
| warna | string | Yes | null | — | Snapshot warna |
| ukuran | string | Yes | null | — | Snapshot ukuran |
| harga | integer | No | 0 | — | Snapshot harga satuan (rupiah) |
| qty | integer | No | 1 | — | Jumlah item |

## Aksi Foreign Key
- order_id → orders (restrict)
- variant_id → variants (restrict)
- product_id → products (set null)

## Perubahan Migrasi
- File: `database/migrations/2026_10_10_000000_add_missing_columns_to_order_items_table.php`
- Run: `php artisan migrate --path=database/migrations/2026_10_10_000000_add_missing_columns_to_order_items_table.php`
- Status: [7] Ran

## File Terkait
- `app/Models/OrderItem.php`
- `app/Http/Controllers/AdminDashboardController.php`

## Catatan
- Tabel order_items saat ini kosong; seeder yang ada tidak mengisi kolom baru.
- Model OrderItem diperbarui: fillable dan casts disesuaikan dari `price`/`quantity` ke `harga`/`qty`.
- AdminDashboardController kini mengembalikan koleksi tertransformasi dengan key `product_name` dan `total_sold`.
