# OrderItems Missing Columns Fix

## Ringkasan
Migrasi tabel order_items berhasil dijalankan:
1. Menambahkan kolom baru yang hilang: order_id, variant_id, product_id, nama, warna, ukuran, harga, qty.
2. Menambahkan foreign key:
   - order_id → orders (restrict)
   - variant_id → variants (restrict)
   - product_id → products (set null)
3. Memperbarui model OrderItem:
   - Menghapus kolom `price` dan `quantity`, menambahkan `harga` dan `qty` (integer).
   - Update fillable, casts.
4. Memperbarui AdminDashboardController:
   - Mengubah dari koleksi raw query menjadi koleksi mapped dengan key yang benar.

## Kolom yang Ditambahkan
- `order_id`: foreignId ke `orders` (restrict)
- `variant_id`: foreignId ke `variants` (restrict)
- `product_id`: foreignId opsional ke `products` (set null)
- `nama`: string, nullable
- `warna`: string, nullable
- `ukuran`: string, nullable
- `harga`: integer, default 0
- `qty`: integer, default 1

## File
- `database/migrations/2026_10_10_000000_add_missing_columns_to_order_items_table.php`
- `app/Models/OrderItem.php`
- `app/Http/Controllers/AdminDashboardController.php`
- `docs/kontrak-props.md`

## Hasil Verifikasi
- php artisan migrate:status → [7] Ran
- php -l .php files: tanpa error sintaksis
- route:list: rute baru tidak ditambahkan

## Langkah untuk Frontend
- Tidak ada: Data yang diterima Frontend melalui Inertia kini sesuai kontrak baru: AdminDashboardController mengembalikan objek OrderItem yang dipetakan dengan `product_name` dan `total_sold`.
- Tidak ada perubahan data yang dikirim dari frontend: order_items dibuat melalui POST /admin/pesanan (OrderController.create), yang meng-copy snapshot dari Variant ke OrderItem menggunakan kolom yang baru ditambahkan.

## Asumsi dan Catatan
- Tabel order_items saat ini kosong (data contoh belum di-seed).


# Fix Admin Dashboard Route/Component Mismatch

## Ringkasan

Perbaiki mismatch: AdminDashboardController merender `AdminDashboard`, padahal komponen berada di `resources/js/Pages/Admin/Dashboard.jsx`. Memperbaiki `App\Http\Controllers\AdminDashboardController.php` dari `AdminDashboard` ke `Admin/Dashboard` dan mencatat pemetaan di docs/kontrak-props.md.

## Ringkasan
Memperbaiki error `TypeError: pages[name] is not a function` pada `resources/js/app.jsx` dengan memastikan fungsi `resolve` memvalidasi komponen sebelum memanggilnya.

## Rencana
- Review `resources/js/app.jsx`.
- Pastikan fungsi `resolve` memvalidasi keberadaan komponen.
- Memastikan penanganan error jika komponen tidak ditemukan.

## File
- `resources/js/app.jsx`

## Hasil Verifikasi
- Belum dicek (Frontend).

## Langkah untuk Frontend
- Tidak ada.

## Asumsi dan Catatan
- Masalah dilaporkan sebagai `TypeError` di `app.jsx`.
- `import.meta.glob` sudah digunakan dengan benar, namun validasi perlu dipastikan.


